package com.obba.onlnbusbkngapp.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "booking")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user; // Links to User entity

    @ManyToOne
    @JoinColumn(name = "bus_id", nullable = false)
    private Bus bus; // Links to Bus entity

    @Column(nullable = false)
    private int numberOfSeats;

    @Enumerated(EnumType.STRING) // Enforces valid status values
    @Column(nullable = false)
    private BookingStatus bookingStatus;

    @CreationTimestamp // Automatically sets booking timestamp
    @Column(nullable = false, updatable = false)
    private LocalDateTime bookingDate;
}

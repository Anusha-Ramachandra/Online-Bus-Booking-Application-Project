package com.obba.onlnbusbkngapp.repository;

import com.obba.onlnbusbkngapp.entity.User;
import com.obba.onlnbusbkngapp.entity.Role; // Import Role Enum
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    //  Find a user by email
    Optional<User> findByEmail(String email);

    // Check if email already exists (for user registration validation)
    boolean existsByEmail(String email);

    // Find all users by role (useful for admin management)
    List<User> findByRole(Role role);
}

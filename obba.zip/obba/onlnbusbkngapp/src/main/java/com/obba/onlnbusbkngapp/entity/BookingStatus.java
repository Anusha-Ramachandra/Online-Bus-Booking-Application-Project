package com.obba.onlnbusbkngapp.entity;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED
}


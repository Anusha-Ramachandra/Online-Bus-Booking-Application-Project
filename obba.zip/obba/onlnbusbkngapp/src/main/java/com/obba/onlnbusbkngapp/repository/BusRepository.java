package com.obba.onlnbusbkngapp.repository;

import com.obba.onlnbusbkngapp.entity.Bus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

public interface BusRepository extends JpaRepository<Bus, Long> {

    Optional<Bus> findByBusNumber(String busNumber); // Prevent duplicate bus numbers

    // Search buses by source & destination
    List<Bus> findBySourceAndDestination(String source, String destination);

    // Search buses by source, destination & departure time range
    List<Bus> findBySourceAndDestinationAndDepartureTimeBetween(
            String source, String destination, LocalTime start, LocalTime end);

    // Search buses departing after a specific time
    List<Bus> findBySourceAndDestinationAndDepartureTimeAfter(
            String source, String destination, LocalTime start);

    // Search buses arriving before a specific time
    List<Bus> findBySourceAndDestinationAndDepartureTimeBefore(
            String source, String destination, LocalTime end);
}

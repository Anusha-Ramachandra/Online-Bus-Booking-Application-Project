package com.obba.onlnbusbkngapp.entity;

import org.springframework.security.core.GrantedAuthority;

public enum Role implements GrantedAuthority {
    ROLE_USER("Regular user who can book tickets"),
    ROLE_OPERATOR("Bus manager who can manage buses and schedules"),
    ROLE_ADMIN("Administrator with full access");

    private final String description;

    Role(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String getAuthority() {
        return name();
    }
}

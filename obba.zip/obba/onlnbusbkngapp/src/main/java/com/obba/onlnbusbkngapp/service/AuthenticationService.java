package com.obba.onlnbusbkngapp.service;

import com.obba.onlnbusbkngapp.dto.RegisterRequest;
import com.obba.onlnbusbkngapp.dto.LoginRequest;
import com.obba.onlnbusbkngapp.dto.AuthResponse;
import com.obba.onlnbusbkngapp.entity.Role;
import com.obba.onlnbusbkngapp.entity.User;
import com.obba.onlnbusbkngapp.repository.UserRepository;
import com.obba.onlnbusbkngapp.security.JwtService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Slf4j
@Service
public class AuthenticationService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthenticationService(UserRepository userRepository,
                                 PasswordEncoder passwordEncoder,
                                 JwtService jwtService,
                                 AuthenticationManager authenticationManager) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
        this.authenticationManager = authenticationManager;
    }

    // Register User with Role Assignment & JWT Token
    public AuthResponse registerUser(RegisterRequest request) {
        log.info("Attempting to register user with email: {}", request.getEmail());

        if (userRepository.findByEmail(request.getEmail()).isPresent()) {
            log.error("Registration failed: Email {} already exists", request.getEmail());
            throw new RuntimeException("Email already exists!");
        }

        User newUser = new User();
        newUser.setName(request.getName());
        newUser.setEmail(request.getEmail());
        newUser.setPassword(passwordEncoder.encode(request.getPassword())); // Encrypt password

        // Assign ROLE_ADMIN if it's an admin email, otherwise ROLE_USER
        if ("admin@gmail.com".equalsIgnoreCase(request.getEmail())) {
            newUser.setRole(Role.ROLE_ADMIN);
        } else {
            newUser.setRole(Role.ROLE_USER);
        }

        userRepository.save(newUser);
        log.info("User registered successfully with role {}: {}", newUser.getRole(), newUser.getEmail());

        // Generate JWT token after successful registration
        String jwtToken = jwtService.generateToken(newUser);
        log.info("JWT Token generated for user {}: {}", newUser.getEmail(), jwtToken);

        return new AuthResponse("User registered successfully!", newUser.getEmail(), newUser.getRole().name(), jwtToken);
    }

    // Login User with JWT Token
    public AuthResponse loginUser(LoginRequest request) {
        log.info("Attempting to authenticate user: {}", request.getEmail());

        try {
            authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );
        } catch (BadCredentialsException e) {
            log.error("Login failed for user {}: Invalid credentials", request.getEmail());
            throw new RuntimeException("Invalid email or password!");
        }

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> {
                    log.error("Login failed: User not found {}", request.getEmail());
                    return new RuntimeException("User not found!");
                });

        String token = jwtService.generateToken(user);
        log.info("User logged in successfully: {} with role: {}", user.getEmail(), user.getRole());

        return new AuthResponse("Login successful!", user.getEmail(), user.getRole().name(), token);
    }
}

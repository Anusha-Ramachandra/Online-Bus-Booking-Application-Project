package com.obba.onlnbusbkngapp.controller;

import com.obba.onlnbusbkngapp.entity.Bus;
import com.obba.onlnbusbkngapp.service.BusService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/buses") // Standardize API path
public class BusController {
    private final BusService busService;
    private static final Logger logger = LoggerFactory.getLogger(BusController.class); //  Add logging

    public BusController(BusService busService) {
        this.busService = busService;
    }

    //  Add a new bus with validation & duplicate bus number check
    @PostMapping("/add")
    public ResponseEntity<?> addBus(@Valid @RequestBody Bus bus) {
        logger.info("Received request to add a new bus: {}", bus);

        try {
            Bus savedBus = busService.addBus(bus);
            return ResponseEntity.ok(savedBus);
        } catch (RuntimeException e) {
            logger.error("Error adding bus: {}", e.getMessage());
            return ResponseEntity.badRequest().body(e.getMessage()); // Handle duplicate bus number error
        }
    }

    //  Get bus by ID with improved error handling
    @GetMapping("/{id}")
    public ResponseEntity<?> getBusById(@PathVariable Long id) {
        logger.info("Fetching bus with ID: {}", id);

        Optional<Bus> bus = busService.getBusById(id);
        return bus.map(ResponseEntity::ok)
                .orElseGet(() -> {
                    logger.warn("Bus with ID {} not found", id);
                    return ResponseEntity.notFound().build();
                });
    }

    //  Get all buses
    @GetMapping("/all")
    public ResponseEntity<List<Bus>> getAllBuses() {
        logger.info("Fetching all buses...");
        List<Bus> buses = busService.getAllBuses();
        return ResponseEntity.ok(buses);
    }

    // Search buses with time filtering & improved error handling
    @GetMapping("/search")
    public ResponseEntity<?> searchBuses(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam(required = false) String departureTime,
            @RequestParam(required = false) String arrivalTime) {

        logger.info("Searching buses from '{}' to '{}' with optional time filters (Departure: {}, Arrival: {})",
                source, destination, departureTime, arrivalTime);

        try {
            List<Bus> buses = busService.searchBuses(source, destination, departureTime, arrivalTime);

            if (buses.isEmpty()) {
                logger.warn("No buses found for the given criteria.");
                return ResponseEntity.ok("No buses found for this route."); //  More user-friendly response
            }

            return ResponseEntity.ok(buses);
        } catch (Exception e) {
            logger.error("Error searching for buses: {}", e.getMessage());
            return ResponseEntity.status(500).body("An error occurred while searching for buses.");
        }
    }
}

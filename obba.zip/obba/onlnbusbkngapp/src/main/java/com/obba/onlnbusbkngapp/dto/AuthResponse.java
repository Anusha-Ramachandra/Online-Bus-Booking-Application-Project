package com.obba.onlnbusbkngapp.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor //  Generates a constructor with all fields
@NoArgsConstructor
public class AuthResponse {
    private String message;
    private String email;
    private String role;
    private String token;
}

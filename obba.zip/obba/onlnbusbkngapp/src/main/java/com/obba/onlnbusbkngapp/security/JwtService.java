package com.obba.onlnbusbkngapp.security;

import com.obba.onlnbusbkngapp.entity.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;

@Service
public class JwtService {

    private static final Logger logger = Logger.getLogger(JwtService.class.getName());

    @Value("${jwt.secret:default_secret_key_change_this}") // Use default if not set
    private String secretKey;

    //  Generate Secret Key for Signing
    private Key getSigningKey() {
        if (secretKey == null || secretKey.isEmpty()) {
            logger.warning(" JWT Secret Key is missing! Using a default key. Update application.properties.");
        }
        return Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.UTF_8));
    }

    //  Generate Token with Role
    public String generateToken(User user) {
        return Jwts.builder()
                .setSubject(user.getEmail())
                .claim("role", user.getRole().name())  //  Ensure Role is Stored
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10)) // 10-hour expiry
                .signWith(getSigningKey(), SignatureAlgorithm.HS256)
                .compact();
    }

    //  Extract Email from Token
    public String extractEmail(String token) {
        return extractClaim(token, Claims::getSubject);
    }

    //  Extract Role from Token (With Fallback)
    public String extractRole(String token) {
        return extractClaim(token, claims -> claims.get("role", String.class) != null ? claims.get("role", String.class) : "ROLE_USER");
    }

    //  Extract Specific Claim
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }

    //  Validate Token (Handles Expiry)
    public boolean validateToken(String token, String userEmail) {
        try {
            String extractedEmail = extractEmail(token);
            return extractedEmail.equals(userEmail) && !isTokenExpired(token);
        } catch (ExpiredJwtException e) {
            logger.warning(" JWT Token has expired: " + e.getMessage());
            return false;
        } catch (Exception e) {
            logger.warning(" Invalid JWT token: " + e.getMessage());
            return false;
        }
    }

    //  Check if Token is Expired
    private boolean isTokenExpired(String token) {
        try {
            return extractClaim(token, Claims::getExpiration).before(new Date());
        } catch (ExpiredJwtException e) {
            return true;
        }
    }

    //  Extract All Claims Safely
    private Claims extractAllClaims(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(getSigningKey())
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (ExpiredJwtException e) {
            logger.warning(" JWT Token Expired: " + e.getMessage());
            throw e;
        } catch (UnsupportedJwtException | MalformedJwtException | SignatureException e) {
            logger.warning(" Invalid JWT Token: " + e.getMessage());
            throw new RuntimeException("Invalid JWT Token", e);
        }
    }
}

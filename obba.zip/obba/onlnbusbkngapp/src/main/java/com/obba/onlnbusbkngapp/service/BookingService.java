package com.obba.onlnbusbkngapp.service;

import com.obba.onlnbusbkngapp.entity.Booking;
import com.obba.onlnbusbkngapp.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    public Booking createBooking(Booking booking) {
        return bookingRepository.save(booking);
    }

    public Optional<Booking> getBookingById(Long id) {
        return bookingRepository.findById(id);
    }

    public List<Booking> getAllBookings() {
        return bookingRepository.findAll();
    }

    public Booking updateBooking(Long id, Booking bookingDetails) {
        return bookingRepository.findById(id).map(booking -> {
            booking.setBookingDate(bookingDetails.getBookingDate());
            booking.setBookingStatus(bookingDetails.getBookingStatus());
            booking.setNumberOfSeats(bookingDetails.getNumberOfSeats());
            return bookingRepository.save(booking);
        }).orElse(null);
    }

    public boolean deleteBooking(Long id) {
        if (bookingRepository.existsById(id)) {
            bookingRepository.deleteById(id);
            return true;
        }
        return false;
    }
}

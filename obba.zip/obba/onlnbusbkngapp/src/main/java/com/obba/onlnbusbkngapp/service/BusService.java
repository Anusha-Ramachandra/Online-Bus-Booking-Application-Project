package com.obba.onlnbusbkngapp.service;

import com.obba.onlnbusbkngapp.entity.Bus;
import com.obba.onlnbusbkngapp.repository.BusRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class BusService {
    private final BusRepository busRepository;
    private static final Logger logger = LoggerFactory.getLogger(BusService.class); // Add logging

    public BusService(BusRepository busRepository) {
        this.busRepository = busRepository;
    }

    //  Add a new bus with duplicate bus number check & logging
    public Bus addBus(Bus bus) {
        logger.info("Attempting to add a new bus: {}", bus);

        if (busRepository.findByBusNumber(bus.getBusNumber()).isPresent()) {
            logger.error("Bus number '{}' already exists! Operation aborted.", bus.getBusNumber());
            throw new RuntimeException("Bus number already exists!"); // Prevent duplicate bus numbers
        }

        Bus savedBus = busRepository.save(bus);
        logger.info("New bus added successfully: {}", savedBus);
        return savedBus;
    }

    // Get bus by ID with logging
    public Optional<Bus> getBusById(Long id) {
        logger.info("Fetching bus with ID: {}", id);
        return busRepository.findById(id);
    }

    // Get all buses with logging
    public List<Bus> getAllBuses() {
        logger.info("Fetching all available buses...");
        return busRepository.findAll();
    }

    // Search buses with optional time filtering & error handling
    public List<Bus> searchBuses(String source, String destination, String departureTime, String arrivalTime) {
        logger.info("Searching for buses from '{}' to '{}' with filters (Departure: {}, Arrival: {})",
                source, destination, departureTime, arrivalTime);

        LocalTime depTime = parseTime(departureTime);
        LocalTime arrTime = parseTime(arrivalTime);

        List<Bus> buses;
        if (depTime != null && arrTime != null) {
            buses = busRepository.findBySourceAndDestinationAndDepartureTimeBetween(source, destination, depTime, arrTime);
        } else if (depTime != null) {
            buses = busRepository.findBySourceAndDestinationAndDepartureTimeAfter(source, destination, depTime);
        } else if (arrTime != null) {
            buses = busRepository.findBySourceAndDestinationAndDepartureTimeBefore(source, destination, arrTime);
        } else {
            buses = busRepository.findBySourceAndDestination(source, destination);
        }

        if (buses.isEmpty()) {
            logger.warn("No buses found for route '{}' to '{}'.", source, destination);
        } else {
            logger.info("Found {} bus(es) for route '{}' to '{}'.", buses.size(), source, destination);
        }

        return buses;
    }

    // Utility method for parsing time
    private LocalTime parseTime(String time) {
        try {
            return (time != null && !time.isEmpty()) ? LocalTime.parse(time) : null;
        } catch (Exception e) {
            logger.error("Invalid time format: {}", time);
            return null;
        }
    }
}

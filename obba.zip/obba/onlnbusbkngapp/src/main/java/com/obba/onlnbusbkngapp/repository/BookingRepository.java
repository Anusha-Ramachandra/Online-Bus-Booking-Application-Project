package com.obba.onlnbusbkngapp.repository;

import com.obba.onlnbusbkngapp.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    // Find all bookings by a specific user (for booking history)
    List<Booking> findByUserId(Long userId);

    // Find all bookings for a specific bus
    List<Booking> findByBusId(Long busId);

    // Find all bookings with a given status (CONFIRMED, CANCELLED)
    List<Booking> findByBookingStatus(String bookingStatus);
}
